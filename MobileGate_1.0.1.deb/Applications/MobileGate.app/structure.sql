CREATE TABLE [list_def] ([ID] INTEGER PRIMARY KEY, [name] TEXT NOT NULL, [list_type] INTEGER NOT NULL, [list_category] INTEGER NOT NULL, [active] INTEGER NOT NULL);
CREATE TABLE [lists] ([ID] INTEGER PRIMARY KEY, [contact] TEXT NOT NULL, [list_def_id] INTEGER NOT NULL REFERENCES [list_def](ID) ON DELETE CASCADE);

CREATE TRIGGER [fk_lists_list_def] BEFORE DELETE ON [list_def] WHEN (old.[ID] IN (SELECT [list_def_id] FROM [lists] GROUP BY [list_def_id])) BEGIN
DELETE FROM [lists] WHERE [list_def_id] = old.[ID];
END;
