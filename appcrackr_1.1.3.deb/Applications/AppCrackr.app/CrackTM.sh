#!/bin/bash
#
# CrackTM Script Made by MadHouse
#
# Special Thanks to tam/CORE, rcg, poedgirl, magik, dissident, Rastignac, and rwxr-xr-x
#

export TERM=xterm 

echo "> CrackTM - 2.6.2 - MadHouse"

input=$1
CrackerName=$2

start=$(date +%s)
if [ ! -e /usr/bin/plutil ]; then
	echo "Missing plutil"
	apt-get install com.ericasadun.utilities
fi

if [ ! -e /usr/bin/awk ]; then
	echo "Missing gawk"
	apt-get install gawk
fi

if [ ! -e /usr/bin/zip ]; then
	echo "Missing zip"
	apt-get install zip
fi

if [ ! -e /usr/bin/gdb ]; then
	echo "Missing gdb"
	apt-get install gdb
fi

if [ ! -e /usr/bin/otool ]; then
	echo "Missing otool"
	apt-get install odcctools
fi

if [ ! -e /usr/bin/ldid ]; then
	echo "Missing ldid"
	apt-get install ldid
fi

echo "Searching for Application"
UUID=$(echo $input | cut -d '/' -f6 )
AppPath="/var/mobile/Applications/$UUID"
if [ $AppCount -gt 1 ]; then
	echo "Found Multiple Install Directories:"
	echo "$AppPath"
	exit 1
fi
if  [ ! $AppPath ]; then
	echo "Application ("$input") Cannot Be Found"
	exit 1
else
	echo "Analyzing Binary"
fi
AppName=$(echo $input | cut -d '/' -f7 )
AppExec=$(plutil -key CFBundleExecutable "$AppPath/$AppName/Info.plist")
AppVer=$(plutil -key CFBundleVersion "$AppPath/$AppName/Info.plist")
AppDisplayName=$(plutil -key CFBundleDisplayName "$AppPath/$AppName/Info.plist")
if [ ! "$AppDisplayName" ]; then
	echo "Using an Alternate Key"
	AppDisplayName=$(plutil -key CFBundleExecutable "$AppPath/$AppName/Info.plist")
fi

if [ ! -d "$AppPath" ]; then
	echo "Unable to Find Install Location"
	exit 1
fi

if [ ! -d "$AppPath/$AppName" ]; then
	echo "Unable to Find App Location"	
	exit 1
fi

if [ ! -e "$AppPath/$AppName/$AppExec" ]; then
	echo "Unable to Find Executable"
	exit 1
fi

CryptSize=$(otool -l "$AppPath/$AppName/$AppExec" | grep cryptsize | awk '{print $2}')
if [ ! $CryptSize ]; then
	echo "Unable to Find CryptSize"
	exit 1
fi

CryptOff=$(otool -l "$AppPath/$AppName/$AppExec" | grep cryptoff | awk '{print $2}')
if [ ! $CryptOff ]; then
	echo "Unable to Find CryptOff"
	exit 1
fi

CryptID=$(otool -l "$AppPath/$AppName/$AppExec" | grep cryptid | awk '{print $2}')
if [ $CryptID != "1" ]; then
	echo "Application is Already Cracked"
	exit 1
fi

FATCheck=$(lipo -info "$AppPath/$AppName/$AppExec" | grep Architectures | awk '{print $2}')
if [ ! $FATCheck ]; then
	sleep .001s
else
	fatbin=1
fi

echo
if [ ! $CrackerName ]; then
	echo "Now Cracking $AppDisplayName Without a Cracker Name, DO NOT INTERRUPT THIS PROCESS!"
else
	echo "Now Cracking $AppDisplayName as $CrackerName, DO NOT INTERRUPT THIS PROCESS!"
fi

echo "Creating Workspace"
WorkDir="/tmp/cracktm/$(date +%m-%d-%Y)/$(date +%H%M%S)"
NewAppDir="/var/mobile/Documents/Cracked"

if [ -e "$WorkDir" ]; then
	rm -rf "$WorkDir"
fi

mkdir -p "$WorkDir"

if [ ! -e "$NewAppDir" ]; then
	mkdir -p "$NewAppDir"
fi

if [ ! -d "$WorkDir" -o ! -d "$NewAppDir" ]; then
	echo "Cannot Create Workspace"
	exit 1
fi

echo "Setting up Application"

mv "$AppPath/$AppName" "$WorkDir/$AppName"

if [ ! -e "$WorkDir/$AppName/$AppExec" ]; then
	echo "Unable to Set up Application"
	rm -rf "$AppPath/$AppName"
	mv "$WorkDir/" "$AppPath/" 
 	exit 1
fi

mkdir -p $AppPath
mkdir -p "$AppPath/$AppName"

cp "$WorkDir/$AppName/$AppExec" "$AppPath/$AppName/$AppExec"

if [ -e "$WorkDir/$AppName/SC_Info" ]; then
	mv "$WorkDir/$AppName/SC_Info" "$AppPath/$AppName/SC_Info"
fi
if [ -e "$WorkDir/$AppName/_CodeSignature" ]; then
	mv "$WorkDir/$AppName/_CodeSignature" "$AppPath/$AppName/_CodeSignature"
fi
if [ -e "$WorkDir/$AppName/CodeResources" ]; then
	mv "$WorkDir/$AppName/CodeResources" "$AppPath/$AppName/CodeResources"
fi
if [ -e "$WorkDir/$AppName/ResourceRules.plist" ]; then
	mv "$WorkDir/$AppName/ResourceRules.plist" "$AppPath/$AppName/ResourceRules.plist"
fi

if [ "$fatbin" = "1" ]; then
	echo "Lipoing Fat Binary"
    mv "$WorkDir/$AppName/$AppExec" fatbinary
    lipo -thin armv6 fatbinary -output thinbinary
	mv thinbinary "$WorkDir/$AppName/$AppExec" 
	rm -rf fatbinary
fi

echo "Dumping Encrypted Data"

echo -e "set sharedlibrary load-rules \".*\" \".*\" none\r\n\
set inferior-auto-start-dyld off\r\n\
set sharedlibrary preload-libraries off\r\n\
set sharedlibrary load-dyld-symbols off\r\n\
handle all nostop\r\n\
rb doModInitFunctions\r\n
command 1\r\n
dump memory $WorkDir/dump.bin 0x2000 $(($CryptSize + 0x2000))\r\n\
kill\r\n\
quit\r\n\
end\r\n\
start" > $WorkDir/batch.gdb

foo=$(gdb -q -e "$AppPath/$AppName/$AppExec" -x $WorkDir/batch.gdb -batch 2>&1> /dev/null)

rm $WorkDir/batch.gdb

echo "Verifying Dump"
DumpSize=$(ls -l "$WorkDir" | grep "dump.bin" | awk '{print $5}')
if [ "$DumpSize" != "$CryptSize" ]; then
	echo "Cannot Dump Memory"
	rm -rf "$AppPath/$AppName"
	mv "$WorkDir/" "$AppPath/" 
	exit 1
fi

echo "Patching CryptID"
od -A n -N 4096 -t x1 --w=4096 "$WorkDir/$AppName/$AppExec" | sed 's/ //g' | sed 's/2f7573722f6c69622f64796c64.*/2f7573722f6c69622f64796c64/g' > "$WorkDir/cryptid.hex"
foo=$(printf "\x0" | dd bs=1 conv=notrunc of="$WorkDir/$AppName/$AppExec" seek=$(expr $(($(stat -c%s "$WorkDir/cryptid.hex") + 253)) / 2)  2>&1 > /dev/null)
rm "$WorkDir/cryptid.hex"

CryptID=$(otool -l "$WorkDir/$AppName/$AppExec" | grep cryptid | awk '{print $2}')
if [ "$CryptID" = "1" ]; then
	echo "Unable to Patch CryptID"
	if [ -e "$AppPath/$AppName/$AppExec" ]; then
		mv "$AppPath/$AppName/$AppExec" "$WorkDir/Payload/$AppName/$AppExec"
	fi
	rm -rf "$AppPath/$AppName"
	mv "$WorkDir/" "$AppPath/" 
	exit 1
fi

echo "Replacing Encrypted Data"
head -c 4096 "$WorkDir/$AppName/$AppExec" > "$WorkDir/head"
tail -c +$(( $CryptSize + 4097 )) "$WorkDir/$AppName/$AppExec" > "$WorkDir/tail"
cat "$WorkDir/head" "$WorkDir/dump.bin" "$WorkDir/tail" > "$WorkDir/$AppName/$AppExec"
rm "$WorkDir/head"
rm "$WorkDir/tail"

cat "$WorkDir/$AppName/$AppExec" > "$WorkDir/2"
rm "$WorkDir/$AppName/$AppExec"
mv "$WorkDir/2" "$WorkDir/$AppName/$AppExec"

echo "Signing Application"
wenis=$(ldid -s "$WorkDir/$AppName/$AppExec")
chmod 777 "$WorkDir/$AppName/$AppExec"
if [ ! $CrackerName ]; then
		sleep .001s
else
	echo "Cracked by $CrackerName on $(date +%m/%d/%Y)." >> "$WorkDir/$AppName/$CrackerName.bin"
fi
echo "Preparing Payload"

mkdir -p "$WorkDir/Payload"
if [ ! -e "$WorkDir/Payload" ]; then
	echo "Cannot Create Payload Folder"
	rm -rf "$AppPath/$AppName"
	mv "$WorkDir/" "$AppPath/" 
 	exit 1
fi
mv "$WorkDir/$AppName" "$WorkDir/Payload/"

if [ -e "$AppPath/iTunesArtwork" ]; then
	cp -a "$AppPath/iTunesArtwork" "$WorkDir/"
	touch "$WorkDir/iTunesArtwork"
else
	echo "Cannot Find iTunesArtwork"
fi

if [ -e "$AppPath/iTunesMetadata.plist" ];then
	cp -a "$AppPath/iTunesMetadata.plist" "$WorkDir/"
	dissident=$(plutil -rmkey 'appleId' "$WorkDir/iTunesMetadata.plist")
	likes=$(plutil -rmkey 'purchaseDate' "$WorkDir/iTunesMetadata.plist")
	big=$(plutil -rmkey 'com.apple.iTunesStore.downloadInfo' "$WorkDir/iTunesMetadata.plist")
	hard=$(cat "$WorkDir/iTunesMetadata.plist" | grep @)
	if [ ! $hard ]; then
		penis=$(plutil -convert binary1 "$WorkDir/iTunesMetadata.plist")
	else
		echo "Unable to Remove Personal Data"
		if [ -e "$AppPath/$AppName/SC_Info" ]; then
			mv "$AppPath/$AppName/SC_Info" "$WorkDir/Payload/$AppName/SC_Info"
		fi
		if [ -e "$AppPath/$AppName/_CodeSignature" ]; then
			mv "$AppPath/$AppName/_CodeSignature" "$WorkDir/Payload/$AppName/_CodeSignature"
		fi
		if [ -e "$AppPath/$AppName/CodeResources" ]; then
			mv "$AppPath/$AppName/CodeResources" "$WorkDir/Payload/$AppName/CodeResources"
		fi
		if [ -e "$AppPath/$AppName/ResourceRules.plist" ]; then
			mv "$AppPath/$AppName/ResourceRules.plist" "$WorkDir/Payload/$AppName/ResourceRules.plist"
		fi
		if [ -e "$AppPath/$AppName/$AppExec" ]; then
			mv "$AppPath/$AppName/$AppExec" "$WorkDir/Payload/$AppName/$AppExec"
		fi
		rm -rf "$AppPath/$AppName"
		mv "$WorkDir/Payload/$AppName/" "$AppPath/"
		mv "$WorkDir/iTunesArtwork" "$AppPath"
		rm -rf "$WorkDir"
	exit 1
	fi
else
	echo "Cannot Find iTunesMetadata.plist"
fi

rm -rf "$WorkDir/dump.bin"

if [ ! $CrackerName ]; then
	IPAName=$NewAppDir/$(echo $AppDisplayName | sed -e "s: ::g")-v$AppVer.ipa
else
	IPAName=$NewAppDir/$(echo $AppDisplayName | sed -e "s: ::g")-v$AppVer-$CrackerName.ipa
fi
echo "Compressing .ipa"
if [ -e "$WorkDir/Payload/$AppName/CodeResources" ]; then
	rm -rf "$WorkDir/Payload/$AppName/CodeResources"
fi
cd "$WorkDir"
zip -2 -y -r "$IPAName" ./ 2>&1> /dev/null
if [ ! -e "$IPAName" ]; then
	echo "Cannot Compress IPA"
	
	if [ -e "$AppPath/$AppName/SC_Info" ]; then
		mv "$AppPath/$AppName/SC_Info" "$WorkDir/Payload/$AppName/SC_Info"
	fi
	if [ -e "$AppPath/$AppName/_CodeSignature" ]; then
		mv "$AppPath/$AppName/_CodeSignature" "$WorkDir/Payload/$AppName/_CodeSignature"
	fi
	if [ -e "$AppPath/$AppName/CodeResources" ]; then
		mv "$AppPath/$AppName/CodeResources" "$WorkDir/Payload/$AppName/CodeResources"
	fi
	if [ -e "$AppPath/$AppName/ResourceRules.plist" ]; then
		mv "$AppPath/$AppName/ResourceRules.plist" "$WorkDir/Payload/$AppName/ResourceRules.plist"
	fi
	if [ -e "$AppPath/$AppName/$AppExec" ]; then
		mv "$AppPath/$AppName/$AppExec" "$WorkDir/Payload/$AppName/$AppExec"
	fi
	rm -rf "$AppPath/$AppName"
	mv "$WorkDir/Payload/$AppName/" "$AppPath/"
	mv "$WorkDir/iTunesArtwork" "$AppPath"
	rm -rf "$WorkDir"
	exit 1
fi

echo "Cleaning Up"

if [ -e "$AppPath/$AppName/SC_Info" ]; then
	mv "$AppPath/$AppName/SC_Info" "$WorkDir/Payload/$AppName/SC_Info"
fi
if [ -e "$AppPath/$AppName/_CodeSignature" ]; then
	mv "$AppPath/$AppName/_CodeSignature" "$WorkDir/Payload/$AppName/_CodeSignature"
fi
if [ -e "$AppPath/$AppName/CodeResources" ]; then
	mv "$AppPath/$AppName/CodeResources" "$WorkDir/Payload/$AppName/CodeResources"
fi
if [ -e "$AppPath/$AppName/ResourceRules.plist" ]; then
	mv "$AppPath/$AppName/ResourceRules.plist" "$WorkDir/Payload/$AppName/ResourceRules.plist"
fi
if [ -e "$AppPath/$AppName/$AppExec" ]; then
	mv "$AppPath/$AppName/$AppExec" "$WorkDir/Payload/$AppName/$AppExec"
fi
rm -rf "$AppPath/$AppName"
mv "$WorkDir/Payload/$AppName/" "$AppPath/"
mv "$WorkDir/iTunesArtwork" "$AppPath"
rm -rf "$WorkDir"
end=$(date +%s)
total=$(( $end - $start ))
	
echo "$AppDisplayName has been successfully cracked."
exit 1
;;

-l)
echo "> CrackTM - 2.6.2 - MadHouse"
echo
export TERM=xterm
echo "Listing All Applications"
width=$(tput cols)
if [ "$width" -lt "50" ]; then
	ls /var/mobile/Applications/* | grep .app | sed -e 's:\\ : :g' | cut -d '.' -f1 2>&1 | sort -f 
	exit 1
else
	rawcols=$(( $width / 25 ))
	cols=$(echo $rawcols | cut -d '.' -f1)
	ls /var/mobile/Applications/* | grep .app | sed -e 's:\\ : :g' | cut -d '.' -f1 2>&1 | sort -f | awk '{printf("%-25.24s", $0)} (NR%cols) == 0 { printf("\n") }' cols="$cols"
	echo
	echo "WARNING: App names longer than 24 characters have been truncated."
	exit 1
fi
;;

-u)
clear
echo "> CrackTM - 2.6.2 - MadHouse"
if [ ! -e /usr/bin/wget ]; then
	echo "Missing wget"
	apt-get install wget
fi
cd /usr/bin
echo
wget -N http://iamthemadhouse.com/files/cracktm
chmod 777 cracktm
;;

-h)
echo -e "To use, type 'cracktm' with the following arguments:
\t -h Display This Menu
\t -l List All Applications
\t -c Crack an Application
\t\t Use 'cracktm -c <App Name> [Cracker Name]'
\t -f Use a fastdumper Interface (Computer Only!)
\t -u Check for and Install Updates"
;;

-f)
if [ $# -ne 1 ];then
	echo "Invalid Argument. Type 'cracktm -h' for help."
	exit 1
fi
export TERM=xterm 
clear

echo "> CrackTM - 2.6.2 - MadHouse"
echo "Listing All Applications"
if [ ! -e /usr/bin/plutil ]; then
	echo "Missing plutil"
	apt-get install com.ericasadun.utilities
fi

if [ ! -e /usr/bin/awk ]; then
	echo "Missing gawk"
	apt-get install gawk
fi

if [ ! -e /usr/bin/zip ]; then
	echo "Missing zip"
	apt-get install zip
fi

if [ ! -e /usr/bin/gdb ]; then
	echo "Missing gdb"
	apt-get install gdb
fi

if [ ! -e /usr/bin/otool ]; then
	echo "Missing otool"
	apt-get install odcctools
fi

if [ ! -e /usr/bin/ldid ]; then
	echo "Missing ldid"
	apt-get install ldid
fi

width=$(tput cols)
if [ "$width" -lt "70" ];then
	ncols=1
	colwidth=$(( $width / $ncols - 5 ))
	colwidth2=$(( $colwidth - 1 ))
	ls /var/mobile/Applications/* | grep .app | sed -e 's:\\ : :g' | cut -d '.' -f1 2>&1 | sed -e 's: :___:g' | sort -f > /tmp/catme.tmp
	cat /tmp/catme.tmp | sed -e 's:___: :g' | awk '{printf("%3d. %-'$colwidth'.'$colwidth2's", NR, $0)} (NR%'$ncols') == 0 { printf("\n") }'
	echo
else
	ncols=3
	colwidth=$(( $width / $ncols - 5 ))
	colwidth2=$(( $colwidth - 1 ))
	ls /var/mobile/Applications/* | grep .app | sed -e 's:\\ : :g' | cut -d '.' -f1 2>&1 | sed -e 's: :___:g' | sort -f > /tmp/catme.tmp
	cat /tmp/catme.tmp | sed -e 's:___: :g' | awk '{printf("%3d. %-'$colwidth'.'$colwidth2's", NR, $0)} (NR%'$ncols') == 0 { printf("\n") }'
	echo "WARNING: Apps with names longer than $colwidth2 characters have been truncated!"
fi
echo
read -p "Please Enter an App Number (Use a Space to Separate More Than One): " numbah
overallstart=$(date +%s)
for num in $numbah; do
test=$(echo "$num" | grep -E [0-9])
if [ ! "$test" ]; then
	echo "$num: Invalid Number"
	exit 1
fi

input=$(cat /tmp/catme.tmp | awk '{printf("%3d. %-'999'.'994's", NR, $0)} (NR%'1') == 0 { printf("\n") }' | grep "$num\." -m 1 | awk '{print $2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15}' | tr -d ' ' | sed -e 's:___: :g')

if [ ! "$input" ]; then
	echo "$num: Invalid Number"
	exit 1
fi
start=$(date +%s)

AppInput=$(echo "$input" | sed -e 's: :\\ :g')
Search=$(echo "$AppInput.app" | sed "s:*:.*:g")
AppPath=$(ls -x /var/mobile/Applications/* | grep -i "$Search" -B 1 | cut -d ':' -f1 2>&1 | grep /var/)
AppCount=$(echo "$AppPath" | wc -l)
if [ $AppCount -gt 1 ]; then
	echo "Found Multiple Install Directories:"
	echo "$AppPath"
	exit 1
fi
if  [ ! $AppPath ]; then
	echo "Application ("$input") Cannot Be Found"
	exit 1
fi

AppName=$(basename $AppPath/*.app)
AppExec=$(plutil -key CFBundleExecutable "$AppPath/$AppName/Info.plist")
AppVer=$(plutil -key CFBundleVersion "$AppPath/$AppName/Info.plist")
AppDisplayName=$(plutil -key CFBundleDisplayName "$AppPath/$AppName/Info.plist")
if [ ! "$AppDisplayName" ]; then
	echo "Using an Alternate Key"
	AppDisplayName=$(plutil -key CFBundleExecutable "$AppPath/$AppName/Info.plist")
fi
echo "Now Cracking $AppDisplayName:"
if [ ! -d "$AppPath" ]; then
	echo "Unable to Find Install Location"
	exit 1
fi

if [ ! -d "$AppPath/$AppName" ]; then
	echo "Unable to Find App Location"	
	exit 1
fi

if [ ! -e "$AppPath/$AppName/$AppExec" ]; then
	echo "Unable to Find Executable"
	exit 1
fi
CryptSize=$(otool -l "$AppPath/$AppName/$AppExec" | grep cryptsize | awk '{print $2}')
if [ ! $CryptSize ]; then
	echo "Unable to Find CryptSize"
	exit 1
fi

CryptOff=$(otool -l "$AppPath/$AppName/$AppExec" | grep cryptoff | awk '{print $2}')
if [ ! $CryptOff ]; then
	echo "Unable to Find CryptOff"
	exit 1
fi

CryptID=$(otool -l "$AppPath/$AppName/$AppExec" | grep cryptid | awk '{print $2}')
if [ $CryptID != "1" ]; then
	echo "Application is Already Cracked"
	exit 1
fi

FATCheck=$(lipo -info "$AppPath/$AppName/$AppExec" | grep Architectures | awk '{print $2}')
if [ ! $FATCheck ]; then
	offset=4096
else
	offset=8192
fi

echo "Creating Workspace"
WorkDir="/tmp/cracktm/$(date +%m-%d-%Y)/$(date +%H%M%S)"
NewAppDir="/var/mobile/Documents/Cracked"

if [ -e "$WorkDir" ]; then
	rm -rf "$WorkDir"
fi

mkdir -p "$WorkDir"

if [ ! -e "$NewAppDir" ]; then
	mkdir -p "$NewAppDir"
fi

if [ ! -d "$WorkDir" -o ! -d "$NewAppDir" ]; then
	echo "Cannot Create Workspace"
	exit 1
fi

echo "Setting up Application"

mv "$AppPath/$AppName" "$WorkDir/$AppName"

if [ ! -e "$WorkDir/$AppName/$AppExec" ]; then
	echo "Unable to Set up Application"
	rm -rf "$AppPath/$AppName"
	mv "$WorkDir/" "$AppPath/" 
 	exit 1
fi

mkdir -p $AppPath
mkdir -p "$AppPath/$AppName"

cp "$WorkDir/$AppName/$AppExec" "$AppPath/$AppName/$AppExec"

if [ -e "$WorkDir/$AppName/SC_Info" ]; then
	mv "$WorkDir/$AppName/SC_Info" "$AppPath/$AppName/SC_Info"
fi
if [ -e "$WorkDir/$AppName/_CodeSignature" ]; then
	mv "$WorkDir/$AppName/_CodeSignature" "$AppPath/$AppName/_CodeSignature"
fi
if [ -e "$WorkDir/$AppName/CodeResources" ]; then
	mv "$WorkDir/$AppName/CodeResources" "$AppPath/$AppName/CodeResources"
fi
if [ -e "$WorkDir/$AppName/ResourceRules.plist" ]; then
	mv "$WorkDir/$AppName/ResourceRules.plist" "$AppPath/$AppName/ResourceRules.plist"
fi

echo "Dumping Encrypted Data"

echo -e "set sharedlibrary load-rules \".*\" \".*\" none\r\n\
set inferior-auto-start-dyld off\r\n\
set sharedlibrary preload-libraries off\r\n\
set sharedlibrary load-dyld-symbols off\r\n\
handle all nostop\r\n\
rb doModInitFunctions\r\n
command 1\r\n
dump memory $WorkDir/dump.bin 0x2000 $(($CryptSize + 0x2000))\r\n\
kill\r\n\
quit\r\n\
end\r\n\
start" > $WorkDir/batch.gdb

foo=$(gdb -q -e "$AppPath/$AppName/$AppExec" -x $WorkDir/batch.gdb -batch 2>&1> /dev/null)

rm $WorkDir/batch.gdb

echo "Verifying Dump"
DumpSize=$(ls -l "$WorkDir" | grep "dump.bin" | awk '{print $5}')
if [ "$DumpSize" != "$CryptSize" ]; then
	echo "Cannot Dump Memory"
	rm -rf "$AppPath/$AppName"
	mv "$WorkDir/" "$AppPath/" 
	exit 1
fi

echo "Patching CryptID"
od -A n -N $offset -t x1 --w=$offset "$WorkDir/$AppName/$AppExec" | sed 's/ //g' | sed 's/2f7573722f6c69622f64796c64.*/2f7573722f6c69622f64796c64/g' > "$WorkDir/cryptid.hex"
foo=$(printf "\x0" | dd bs=1 conv=notrunc of="$WorkDir/$AppName/$AppExec" seek=$(expr $(($(stat -c%s "$WorkDir/cryptid.hex") + 253)) / 2)  2>&1 > /dev/null)
rm "$WorkDir/cryptid.hex"

CryptID=$(otool -l "$WorkDir/$AppName/$AppExec" | grep cryptid | awk '{print $2}')
if [ "$CryptID" = "1" ]; then
	echo "Unable to Patch CryptID"
	if [ -e "$AppPath/$AppName/$AppExec" ]; then
		mv "$AppPath/$AppName/$AppExec" "$WorkDir/Payload/$AppName/$AppExec"
	fi
	rm -rf "$AppPath/$AppName"
	mv "$WorkDir/" "$AppPath/" 
	exit 1
fi

echo "Replacing Encrypted Data"
head -c $offset "$WorkDir/$AppName/$AppExec" > "$WorkDir/head"
tail -c +$(( $CryptSize + $offset + 1 )) "$WorkDir/$AppName/$AppExec" > "$WorkDir/tail"
cat "$WorkDir/head" "$WorkDir/dump.bin" "$WorkDir/tail" > "$WorkDir/$AppName/$AppExec"
rm "$WorkDir/head"
rm "$WorkDir/tail"
echo "Rebuilding Executable"
cat "$WorkDir/$AppName/$AppExec" > "$WorkDir/2"
rm "$WorkDir/$AppName/$AppExec"
mv "$WorkDir/2" "$WorkDir/$AppName/$AppExec"
chmod 777 "$WorkDir/$AppName/$AppExec"

if [ "$offset" = "8192" ]; then
	echo "Lipoing Fat Binary"
    mv "$WorkDir/$AppName/$AppExec" "$WorkDir/fat"
    lipo -thin armv6 "$WorkDir/fat" -output "$WorkDir/thin"
	mv "$WorkDir/thin" "$WorkDir/$AppName/$AppExec"
	rm -rf "$WorkDir/fat"
fi

echo "Signing Application"
chmod 777 "$WorkDir/$AppName/$AppExec"
ldid -s "$WorkDir/$AppName/$AppExec"
if [ ! $CrackerName ]; then
		sleep .001s
else
	echo "Cracked by $CrackerName on $(date +%m/%d/%Y)." >> "$WorkDir/$AppName/$CrackerName.bin"
fi
echo "Preparing Payload"

mkdir -p "$WorkDir/Payload"
if [ ! -e "$WorkDir/Payload" ]; then
	echo "Cannot Create Payload Folder"
	rm -rf "$AppPath/$AppName"
	mv "$WorkDir/" "$AppPath/" 
 	exit 1
fi
mv "$WorkDir/$AppName" "$WorkDir/Payload/"

if [ -e "$AppPath/iTunesArtwork" ]; then
	cp -a "$AppPath/iTunesArtwork" "$WorkDir/"
	touch "$WorkDir/iTunesArtwork"
else
	echo "Cannot Find iTunesArtwork"
fi

if [ -e "$AppPath/iTunesMetadata.plist" ];then
	cp -a "$AppPath/iTunesMetadata.plist" "$WorkDir/"
	dissident=$(plutil -rmkey 'appleId' "$WorkDir/iTunesMetadata.plist")
	likes=$(plutil -rmkey 'purchaseDate' "$WorkDir/iTunesMetadata.plist")
	big=$(plutil -rmkey 'com.apple.iTunesStore.downloadInfo' "$WorkDir/iTunesMetadata.plist")
	hard=$(cat "$WorkDir/iTunesMetadata.plist" | grep @)
	if [ ! $hard ]; then
		penis=$(plutil -convert binary1 "$WorkDir/iTunesMetadata.plist")
	else
		echo "Unable to Remove Personal Data"
		if [ -e "$AppPath/$AppName/SC_Info" ]; then
			mv "$AppPath/$AppName/SC_Info" "$WorkDir/Payload/$AppName/SC_Info"
		fi
		if [ -e "$AppPath/$AppName/_CodeSignature" ]; then
			mv "$AppPath/$AppName/_CodeSignature" "$WorkDir/Payload/$AppName/_CodeSignature"
		fi
		if [ -e "$AppPath/$AppName/CodeResources" ]; then
			mv "$AppPath/$AppName/CodeResources" "$WorkDir/Payload/$AppName/CodeResources"
		fi
		if [ -e "$AppPath/$AppName/ResourceRules.plist" ]; then
			mv "$AppPath/$AppName/ResourceRules.plist" "$WorkDir/Payload/$AppName/ResourceRules.plist"
		fi
		if [ -e "$AppPath/$AppName/$AppExec" ]; then
			mv "$AppPath/$AppName/$AppExec" "$WorkDir/Payload/$AppName/$AppExec"
		fi
		rm -rf "$AppPath/$AppName"
		mv "$WorkDir/Payload/$AppName/" "$AppPath/"
		mv "$WorkDir/iTunesArtwork" "$AppPath"
		rm -rf "$WorkDir"
	exit 1
	fi
else
	echo "Cannot Find iTunesMetadata.plist"
fi

rm -rf "$WorkDir/dump.bin"

if [ ! $CrackerName ]; then
	IPAName=$NewAppDir/$(echo $AppDisplayName | sed -e "s: ::g")-v$AppVer.ipa
else
	IPAName=$NewAppDir/$(echo $AppDisplayName | sed -e "s: ::g")-v$AppVer-$CrackerName.ipa
fi
echo "Compressing .ipa"
if [ -e "$WorkDir/Payload/$AppName/CodeResources" ]; then
	rm -rf "$WorkDir/Payload/$AppName/CodeResources"
fi
cd "$WorkDir"
zip -2 -y -r "$IPAName" ./ 2>&1> /dev/null
if [ ! -e "$IPAName" ]; then
	echo "Cannot Compress IPA"
	
	if [ -e "$AppPath/$AppName/SC_Info" ]; then
		mv "$AppPath/$AppName/SC_Info" "$WorkDir/Payload/$AppName/SC_Info"
	fi
	if [ -e "$AppPath/$AppName/_CodeSignature" ]; then
		mv "$AppPath/$AppName/_CodeSignature" "$WorkDir/Payload/$AppName/_CodeSignature"
	fi
	if [ -e "$AppPath/$AppName/CodeResources" ]; then
		mv "$AppPath/$AppName/CodeResources" "$WorkDir/Payload/$AppName/CodeResources"
	fi
	if [ -e "$AppPath/$AppName/ResourceRules.plist" ]; then
		mv "$AppPath/$AppName/ResourceRules.plist" "$WorkDir/Payload/$AppName/ResourceRules.plist"
	fi
	if [ -e "$AppPath/$AppName/$AppExec" ]; then
		mv "$AppPath/$AppName/$AppExec" "$WorkDir/Payload/$AppName/$AppExec"
	fi
	rm -rf "$AppPath/$AppName"
	mv "$WorkDir/Payload/$AppName/" "$AppPath/"
	mv "$WorkDir/iTunesArtwork" "$AppPath"
	rm -rf "$WorkDir"
	exit 1
fi

echo "Cleaning Up"

if [ -e "$AppPath/$AppName/SC_Info" ]; then
	mv "$AppPath/$AppName/SC_Info" "$WorkDir/Payload/$AppName/SC_Info"
fi
if [ -e "$AppPath/$AppName/_CodeSignature" ]; then
	mv "$AppPath/$AppName/_CodeSignature" "$WorkDir/Payload/$AppName/_CodeSignature"
fi
if [ -e "$AppPath/$AppName/CodeResources" ]; then
	mv "$AppPath/$AppName/CodeResources" "$WorkDir/Payload/$AppName/CodeResources"
fi
if [ -e "$AppPath/$AppName/ResourceRules.plist" ]; then
	mv "$AppPath/$AppName/ResourceRules.plist" "$WorkDir/Payload/$AppName/ResourceRules.plist"
fi
if [ -e "$AppPath/$AppName/$AppExec" ]; then
	mv "$AppPath/$AppName/$AppExec" "$WorkDir/Payload/$AppName/$AppExec"
fi
rm -rf "$AppPath/$AppName"
mv "$WorkDir/Payload/$AppName/" "$AppPath/"
mv "$WorkDir/iTunesArtwork" "$AppPath"
rm -rf "$WorkDir"
end=$(date +%s)
total=$(( $end - $start ))
	
echo
echo "$AppDisplayName successfully cracked."
done
rm /tmp/catme.tmp
overallend=$(date +%s)
overall=$(( $overallend - $overallstart ))
AppNumber=$(echo "$numbah" | wc -w)
if [ "$AppNumber" -gt "1" ]; then
	echo
	echo "Finished $AppNumber Apps in $overall Seconds!"
fi
exit 1
;;


*)
echo "Invalid Argument. Type 'cracktm -h' for help."
exit 1
;;

esac
exit 1