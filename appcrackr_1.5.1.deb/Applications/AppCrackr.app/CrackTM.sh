start=$(date +%s)
AppPath=$(dirname "$1")
AppName=$(basename "$1")
CrackerName=$2
AppExec=$(plutil -key CFBundleExecutable "$AppPath/$AppName/Info.plist")
AppVer=$(plutil -key CFBundleVersion "$AppPath/$AppName/Info.plist")
AppDisplayName=$(plutil -key CFBundleDisplayName "$AppPath/$AppName/Info.plist")
if [ ! "$AppDisplayName" ]; then
	echo "Using an Alternate Key"
	AppDisplayName=$(plutil -key CFBundleExecutable "$AppPath/$AppName/Info.plist")
fi

if [ ! -d "$AppPath" ]; then
	echo "Unable to Find Install Location"
	exit 1
fi

if [ ! -d "$AppPath/$AppName" ]; then
	echo "Unable to Find App Location"	
	exit 1
fi

if [ ! -e "$AppPath/$AppName/$AppExec" ]; then
	echo "Unable to Find Executable"
	exit 1
fi
CryptSize=$(otool -l "$AppPath/$AppName/$AppExec" | grep cryptsize | awk '{print $2}')
if [ ! $CryptSize ]; then
	echo "Unable to Find CryptSize"
	exit 1
fi

CryptOff=$(otool -l "$AppPath/$AppName/$AppExec" | grep cryptoff | awk '{print $2}')
if [ ! $CryptOff ]; then
	echo "Unable to Find CryptOff"
	exit 1
fi

CryptID=$(otool -l "$AppPath/$AppName/$AppExec" | grep cryptid | awk '{print $2}')
if [ $CryptID != "1" ]; then
	echo "Application is Already Cracked"
	exit 1
fi

KALICheck=$(otool -l "$AppPath/$AppName/$AppExec" | grep __KALI)
if [ ! "$KALICheck" ]; then
	sleep .001s
else
	echo "App is Protected with Kali AP"
	exit 1
fi

FATCheck=$(lipo -info "$AppPath/$AppName/$AppExec" | grep Architectures | awk '{print $2}')
if [ ! "$FATCheck" ]; then
	offset=4096
else
	offset=8192
fi
echo "0% Now Cracking $AppDisplayName:"
echo "5% Creating Workspace"
WorkDir="/tmp/cracktm/$(date +%m%d%Y%H%M%S)"
aiite="/tmp/cracktm/aiite"
NewAppDir="/var/mobile/Documents/Cracked"

if [ -e "$WorkDir" ]; then
	rm -rf "$WorkDir"
fi

if [ ! -e "$aiite" ]; then
	mkdir -p "$aiite"
fi

ln -s "$AppPath" "$WorkDir"

if [ ! -e "$NewAppDir" ]; then
	mkdir -p "$NewAppDir"
fi

if [ ! -d "$WorkDir" -o ! -d "$NewAppDir" -o ! -d "$aiite" ]; then
	echo "Cannot Create Workspace"
	exit 1
fi

echo "10% Setting up Application"

if [ ! -e "$WorkDir/$AppName/$AppExec" ]; then
	echo "Unable to Set up Application" 
 	exit 1
fi

cp "$WorkDir/$AppName/$AppExec" "$aiite/$AppExec"
cp "$WorkDir/iTunesMetadata.plist" "$aiite/iTunesMetadata.plist"
cp "$WorkDir/iTunesArtwork" "$aiite/iTunesArtwork"

echo "15% Dumping Encrypted Data"

echo -e "set sharedlibrary load-rules \".*\" \".*\" none\r\n\
set inferior-auto-start-dyld off\r\n\
set sharedlibrary preload-libraries off\r\n\
set sharedlibrary load-dyld-symbols off\r\n\
handle all nostop\r\n\
rb doModInitFunctions\r\n
command 1\r\n
dump memory $aiite/dump.bin 0x2000 $(($CryptSize + 0x2000))\r\n\
kill\r\n\
quit\r\n\
end\r\n\
start" > "$aiite/batch.gdb"

foo=$(gdb -q -e "$AppPath/$AppName/$AppExec" -x "$aiite/batch.gdb" -batch 2>&1> /dev/null)

rm "$aiite/batch.gdb"

echo "30% Verifying Dump"
DumpSize=$(ls -l "$aiite" | grep "dump.bin" | awk '{print $5}')
if [ "$DumpSize" != "$CryptSize" ]; then
	echo "Cannot Dump Memory"
	rm -rf "$aiite"
	rm "$WorkDir"
	exit 1
fi

echo "40% Patching CryptID"
od -A n -N $offset -t x1 --w=$offset "$aiite/$AppExec" | sed 's/ //g' | sed 's/2f7573722f6c69622f64796c64.*/2f7573722f6c69622f64796c64/g' > "$aiite/cryptid.hex"
foo=$(printf "\x0" | dd bs=1 conv=notrunc of="$aiite/$AppExec" seek=$(expr $(($(stat -c%s "$aiite/cryptid.hex") + 253)) / 2)  2>&1 > /dev/null)
rm "$aiite/cryptid.hex"

CryptID=$(otool -l "$aiite/$AppExec" | grep cryptid | awk '{print $2}')
if [ "$CryptID" = "1" ]; then
	echo "Unable to Patch CryptID"
	rm -rf "$aiite"
	rm "$WorkDir"
	exit 1
fi

echo "60% Replacing Encrypted Data"
CrackTM=$(dd seek=1 bs=$offset conv=notrunc if="$aiite/dump.bin" of="$aiite/$AppExec" 2>&1> /dev/null)

echo "70% Rebuilding Executable"
cat "$aiite/$AppExec" > "$aiite/2"
mv "$aiite/2" "$aiite/$AppExec"
chmod 777 "$aiite/$AppExec"

if [ "$offset" = "8192" ]; then
	echo "75% Lipoing Fat Binary"
    mv "$aiite/$AppExec" "$aiite/fat"
    lipo -thin armv6 "$aiite/fat" -output "$aiite/$AppExec"
	rm -rf "$aiite/fat"
fi

echo "80% Signing Application"
chmod 777 "$aiite/$AppExec"
ldid -s "$aiite/$AppExec"
if [ $CrackerName ]; then
	echo "Cracked by $CrackerName on $(date +%m/%d/%Y)." >> "$WorkDir/$AppName/$CrackerName.bin"
fi
echo "90% Preparing Payload"

if [ -e "$aiite/iTunesArtwork" ]; then
	touch "$aiite/iTunesArtwork"
else
	echo "Cannot Find iTunesArtwork"
fi

if [ -e "$aiite/iTunesMetadata.plist" ];then
	dissident=$(plutil -rmkey 'appleId' "$aiite/iTunesMetadata.plist")
	is=$(plutil -rmkey 'purchaseDate' "$aiite/iTunesMetadata.plist")
	my=$(plutil -rmkey 'com.apple.iTunesStore.downloadInfo' "$aiite/iTunesMetadata.plist")
	hero=$(cat "$aiite/iTunesMetadata.plist" | grep @)
	if [ ! "$hero" ]; then
		COOLBEANS=$(plutil -binary "$aiite/iTunesMetadata.plist")
	else
		echo "Unable to Remove Personal Data"
		mv "$aiite/$AppExec" "$AppPath/$AppName/$AppExec"
		mv "$aiite/iTunesMetadata.plist" "$AppPath/iTunesMetadata.plist"
		rm -rf "$aiite"
		rm "$WorkDir"
		exit 1
	fi
else
	echo "Cannot Find iTunesMetadata.plist"
fi

rm -rf "$aiite/dump.bin"

mkdir -p "$WorkDir/Payload"
if [ ! -e "$WorkDir/Payload" ]; then
	echo "Cannot Create Payload Folder"
	rm -rf "$aiite"
	rm "$WorkDir" 
 	exit 1
fi
mv "$WorkDir/$AppName" "$WorkDir/Payload/"

if [ ! "$CrackerName" ]; then
	IPAName=$NewAppDir/$(echo $AppDisplayName | tr -d ' ')-$AppVer.ipa
else
	IPAName=$NewAppDir/$(echo $AppDisplayName | tr -d ' ')-$AppVer-$CrackerName.ipa
fi

mv "$AppPath/iTunesArtwork" "$aiite/iTunesArtwork.original"
mv "$aiite/iTunesArtwork" "$AppPath/iTunesArtwork"

mv "$WorkDir/Payload/$AppName/$AppExec" "$aiite/$AppExec.original"
touch -r "$aiite/$AppExec.original" "$aiite/$AppExec"
mv "$aiite/$AppExec" "$AppPath/Payload/$AppName/$AppExec"


mv "$WorkDir/iTunesMetadata.plist" "$aiite/iTunesMetadata.plist.original"
mv "$aiite/iTunesMetadata.plist" "$AppPath/iTunesMetadata.plist"

IPASize=$(du -s -m "$AppPath" | awk '{print $1}')
echo "95% Compressing .ipa ($IPASize MB)"
cd "$WorkDir"
zip -2 -qq -r "$IPAName" ./ -x "Documents/*" "Library/*" "tmp/*" "Payload/$AppName/SC_Info/*" "Payload/$AppName/_CodeSignature/*" "Payload/$AppName/CodeResources" "Payload/$AppName/ResourceRules.plist"
if [ ! -e "$IPAName" ]; then
	echo "Unable to Compress IPA"
	rm "$AppPath/iTunesMetadata.plist"
	rm "$AppPath/Payload/$AppName/$AppExec"
	rm "$AppPath/iTunesArtwork"
	mv "$aiite/iTunesMetadata.plist.original" "$AppPath/iTunesMetadata.plist"
	mv "$aiite/iTunesArtwork.original" "$AppPath/iTunesArtwork"
	mv "$aiite/$AppExec.original" "$AppPath/Payload/$AppName/$AppExec"
	mv "$AppPath/Payload/$AppName" "$AppPath/"
	rm -rf "$aiite"
	rm -rf "$WorkDir/$AppName/$CrackerName.bin"
	rm "$WorkDir"
	exit 1
fi

echo "99% Cleaning Up"
rm "$AppPath/iTunesMetadata.plist"
rm "$AppPath/Payload/$AppName/$AppExec"
rm "$AppPath/iTunesArtwork"
mv "$aiite/iTunesMetadata.plist.original" "$AppPath/iTunesMetadata.plist"
mv "$aiite/iTunesArtwork.original" "$AppPath/iTunesArtwork"
mv "$aiite/$AppExec.original" "$AppPath/Payload/$AppName/$AppExec"
mv "$AppPath/Payload/$AppName" "$AppPath/"
rm -rf "$aiite"
rm -rf "$WorkDir/$AppName/$CrackerName.bin"
rm "$WorkDir"

end=$(date +%s)
total=$(( $end - $start ))

echo "100% Decrypted Application Finished in $total Seconds and is Available at $IPAName"

exit 1