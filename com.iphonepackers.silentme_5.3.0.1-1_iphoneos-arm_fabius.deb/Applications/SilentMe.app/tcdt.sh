#!/bin/sh
today=$(exec "date" "+%Y%m%d%H%M.%S")
touch -t $today /Applications/SilentMe.app/*
