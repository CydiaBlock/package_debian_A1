#!/bin/bash

export PATH=$PATH:/usr/sbin:/usr/bin:/sbin:/bin

sysctl -w net.inet.tcp.recvspace=292000
sysctl -w net.inet.tcp.delayed_ack=0
sysctl -w net.inet.tcp.maxseg_unacked=16
sysctl -w net.inet.tcp.mssdflt=1460

