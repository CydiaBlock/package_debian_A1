#!/bin/sh
#
# restoremetadata.sh
# Restores all metadata backups
# Created by Neon

clear

ls -d /var/mobile/Applications/*/*.app | sort -f -t \/ -k 6 | while read OneApp
do
        AppName=$(echo $OneApp | cut -f 6 -d '/')
        cd "$OneApp";
        if [ ! -d SC_Info ]; then
        cd ..
        if [ -f MetadataBackup.plist ]; then
        mv MetadataBackup.plist iTunesMetadata.plist
        fi
        fi
done
exit 1