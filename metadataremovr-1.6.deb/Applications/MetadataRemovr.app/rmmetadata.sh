#!/bin/sh
#
# rmmetadata.sh
# Removes metadata and makes a backup for future use
# Created by fusen

clear

ls -d /var/mobile/Applications/*/*.app | sort -f -t \/ -k 6 | while read OneApp
do
        AppName=$(echo $OneApp | cut -f 6 -d '/')
        cd "$OneApp";
        if [ ! -d SC_Info ]; then
        cd ..
        if [ -f iTunesMetadata.plist ]; then
        mv iTunesMetadata.plist MetadataBackup.plist
        fi
        fi
done
exit 1